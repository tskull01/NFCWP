/**
 * Created by Tskulley on 2/16/2018.
 */
$('.carousel').carousel({
    interval: 2000
})