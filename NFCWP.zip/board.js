
$(document).ready(function(){
    $("#multiCollapseExample1").on("hide.bs.collapse", function(){
        $(".a").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample1").on("show.bs.collapse", function(){
        $(".a").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample2").on("hide.bs.collapse", function(){
        $(".b").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample2").on("show.bs.collapse", function(){
        $(".b").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample3").on("hide.bs.collapse", function(){
        $(".c").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample3").on("show.bs.collapse", function(){
        $(".c").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample4").on("hide.bs.collapse", function(){
        $(".d").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample4").on("show.bs.collapse", function(){
        $(".d").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample5").on("hide.bs.collapse", function(){
        $(".e").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample5").on("show.bs.collapse", function(){
        $(".e").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample6").on("hide.bs.collapse", function(){
        $(".f").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample6").on("show.bs.collapse", function(){
        $(".f").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample7").on("hide.bs.collapse", function(){
        $(".g").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample7").on("show.bs.collapse", function(){
        $(".g").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample8").on("hide.bs.collapse", function(){
        $(".h").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample8").on("show.bs.collapse", function(){
        $(".h").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample9").on("hide.bs.collapse", function(){
        $(".i").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample9").on("show.bs.collapse", function(){
        $(".i").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample10").on("hide.bs.collapse", function(){
        $(".j").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample10").on("show.bs.collapse", function(){
        $(".j").html('<i class="fas fa-angle-down"></i>');
    });
    $("#multiCollapseExample11").on("hide.bs.collapse", function(){
        $(".k").html('<i class="fa fa-chevron-right"></i>');
    });
    $("#multiCollapseExample11").on("show.bs.collapse", function(){
        $(".k").html('<i class="fas fa-angle-down"></i>');
    });
});