
<footer class="footer" style="border-top:1px solid #FCF7E9;background-color: #2a2d32;padding-top:2%;padding-bottom:2%;">
  <div class="container ">
    <div class="row" style="width:100%;">
      <div class="col-9">
         <h6 class="text-muted"style="">© 2004-2018 National Family Court Watch Project</h6>
          <h6 class="text-muted">NFCWP is a nonprofit public charity exempt from federal income tax under the law section 501(c)(3) of the Internal Revenue Code.</h6>
        </div>
        <div class="col-3" style="padding-top:20px; line-height:200%;">
            <h6 class="text-muted" style="text-decoration:none;color:black;">
                510 Highland Avenue<br>
                Milford, MI 48381<br>
                Phone: (248)752-8623<br>
                Email:Renee.beeker@gmail.com
            </h6>
        </div>
     </div>
  </div>
   <div class="container" style="word-spacing: 5px;padding-top:0.5%;">
    <div class="row" style="width:100%;">
      <div class="col">
            <a href="#privacy" style="border-right: 1px solid lightgrey;color:white;"> Privacy </a>
            <a href="#terms" style="padding-left: 1.5%;border-right: 1px solid lightgrey;color:white;"> Terms & Disclaimer </a>
        <a href="#" style="padding-left: 7px;border-right: 1px solid lightgrey;color:white;"> Donate </a>
            <a href="#contact" style="padding-left: 1.5%;color:white;"> Contact </a>
       </div>
      <div class="col" >
             <a href="https://twitter.com/nfcwp" style="color:black;"> <i class="fab fa-twitter"></i></a>
             <a href="https://il.linkedin.com/in/renee-beeker-46148212?trk=org-employees_mini-profile_title" style="color:black;padding-left:1.5%;"> <i class="fab fa-linkedin-in"></i> </a>
        <a href="#" style="color:black;padding-left:1.5%; "><i class="fab fa-facebook-f"></i></a>
      </div>
    </div>
</div>
</footer>